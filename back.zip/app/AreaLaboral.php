<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AreaLaboral extends Model
{
    protected $table = "areas_laborales";
     protected $hidden = ['created_at', 'updated_at'];
}
