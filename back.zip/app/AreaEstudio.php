<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AreaEstudio extends Model
{
    protected $table = 'areas_estudios';
     protected $hidden = ['created_at', 'updated_at'];
}
